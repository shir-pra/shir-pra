﻿using JWTSecurityWithCQRS_Feb20.Models;
using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Commands
{
    //updating a productcommand to have a List as a response 
    public record UpdateProductCommand(Product product):IRequest<List<Product>>; 
   
}
