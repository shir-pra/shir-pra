﻿using JWTSecurityWithCQRS_Feb20.Models;
using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Commands
{
    //adding a productcommand to have a List as a response
    public record AddProductCommand(Product product):IRequest<List<Product>>;
   
}
