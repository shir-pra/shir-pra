﻿using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Commands
{
    //deleting a productcommand to have a string as a response 
    public record DeleteProductCommand(int id):IRequest<string>;  
   
}
