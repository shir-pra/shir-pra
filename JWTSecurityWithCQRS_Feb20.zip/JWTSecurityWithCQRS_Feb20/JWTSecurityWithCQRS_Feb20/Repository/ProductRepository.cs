﻿using JWTSecurityWithCQRS_Feb20.DataAccess;
using JWTSecurityWithCQRS_Feb20.Models;

namespace JWTSecurityWithCQRS_Feb20.Repository
{
    //creating a repository named productrepository and implementing interface methods
    public class ProductRepository:IProduct
    {
        private readonly UserDataBaseContext _context;
        public ProductRepository(UserDataBaseContext context)
        {
            _context = context;
        }

        //adding a new product to database
        public List<Product> Create(Product product)
        {
            
            _context.Products.Add(product);
            _context.SaveChanges();
            return _context.Products.ToList(); 

        }
        //deleting a product by Id
        public string Delete(int id)
        {
            var delId = _context.Products.Find(id);
            if (delId != null)
            {
                _context.Products.Remove(delId);
                _context.SaveChanges();
                return "Successful";
            }
            else
            {
                return "ProductId not found";
            }
        }
        //Getting all the products 
        public List<Product> GetAll()
        {
            return _context.Products.ToList(); 
        }

        //updating the existing product details
        public List<Product> Update(Product product)
        {
            var updateId = _context.Products.Find(product.ProductId);
            if (updateId != null)
            {
                updateId.ProductId= product.ProductId;
                updateId.ProductName= product.ProductName;
                updateId.ProductCost= product.ProductCost;
            }
            _context.SaveChanges();
            return _context.Products.ToList(); 
        }
    }
}
