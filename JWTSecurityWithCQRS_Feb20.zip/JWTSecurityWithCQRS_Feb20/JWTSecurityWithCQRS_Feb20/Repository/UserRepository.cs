﻿using JWTSecurityWithCQRS_Feb20.DataAccess;
using JWTSecurityWithCQRS_Feb20.Models;

namespace JWTSecurityWithCQRS_Feb20.Repository
{
    //creating a repository named userrepository and implementing interface methods
    public class UserRepository:IUser
    {
        private readonly UserDataBaseContext _context;
        public UserRepository(UserDataBaseContext context)
        {
            _context = context;
        }
        //adding a new user
        public List<Tuser> CreateUsers(Tuser user)
        {
           _context.Tusers.Add(user);
            _context.SaveChanges();
            return _context.Tusers.ToList(); 
        }
        //deleting a userid 
        public string DeleteUser(int id)
        {
            var userid = _context.Tusers.Find(id);
            if(userid != null)
            {
                _context.Tusers.Remove(userid);
                _context.SaveChanges();
                return "Successful";
            }
            else
            {
                return "Userid not found"; 
            }

        }

        //getting all the users
        public List<Tuser> GetAllUsers()
        {
            return _context.Tusers.ToList();
        }

        //updating the existing user details
        public List<Tuser> UpdateUsers(Tuser user)
        {
           // _context.Tusers.Update(user); 
            var upId = _context.Tusers.Find(user.Id);
            if(upId != null) 
            {
                upId.Id = user.Id;
                upId.UserId = user.UserId;
                upId.Password=user.Password;
                upId.Role=user.Role;
            }
            _context.SaveChanges();
            return _context.Tusers.ToList(); 
        }
    }
}
