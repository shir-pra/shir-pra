﻿using JWTSecurityWithCQRS_Feb20.Models;

namespace JWTSecurityWithCQRS_Feb20.DataAccess
{
    //creating a interface for Products
    public interface IProduct
    {
        //These all are the methods of Interface
        List<Product>Create(Product product);
        List<Product> Update(Product product);
        List<Product> GetAll();
        public string Delete(int id); 
    }
}
