﻿using JWTSecurityWithCQRS_Feb20.Models;

namespace JWTSecurityWithCQRS_Feb20.DataAccess
{
    //It is a interface named IUser, so, we can just declare the method.
    public interface IUser
    {
        //These all are the methods of Interface
        List<Tuser>CreateUsers(Tuser user);
        List<Tuser> UpdateUsers(Tuser user);
        List<Tuser> GetAllUsers();
        public string DeleteUser(int id);

    }
}
