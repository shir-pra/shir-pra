﻿using System;
using System.Collections.Generic;

namespace JWTSecurityWithCQRS_Feb20.Models
{
    //It is a model class created in the database named Tuser 
    public partial class Tuser
    {
        public int Id { get; set; }
        public string? UserId { get; set; }
        public string? Password { get; set; }
        public string? Role { get; set; }
       
    }
}
