﻿using System;
using System.Collections.Generic;

namespace JWTSecurityWithCQRS_Feb20.Models
{
    //It is a model class created in the database named Product
    public partial class Product
    {
        public int ProductId { get; set; }
        public string? ProductName { get; set; }
        public int? ProductCost { get; set; }
    }
}
