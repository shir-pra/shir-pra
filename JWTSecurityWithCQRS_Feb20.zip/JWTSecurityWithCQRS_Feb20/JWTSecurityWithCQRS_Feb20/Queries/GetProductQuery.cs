﻿using JWTSecurityWithCQRS_Feb20.Models;
using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Queries
{
    //getting a productcommand to have a List as a response
    public record GetProductQuery:IRequest<List<Product>>; 
    
}
