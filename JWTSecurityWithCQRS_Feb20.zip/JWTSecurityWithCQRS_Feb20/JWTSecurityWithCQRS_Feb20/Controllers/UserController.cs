﻿using JWTSecurityWithCQRS_Feb20.Queries;
using MediatR;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JWTSecurityWithCQRS_Feb20.Controllers
{

    [EnableCors("swagger")] 
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        //Communication Using Mediator
        private readonly IMediator _mediator;
        public UserController(IMediator mediator)
        {
           _mediator = mediator;
        }
        [HttpGet]
        [Route("getAllProducts")] 
        //getting all the products 
        public async Task<ActionResult>GetAllUsers()
        {
            var users = _mediator.Send(new GetProductQuery());
            return Ok(users); 
        }
    }
}
