﻿using JWTSecurityWithCQRS_Feb20.Commands;
using JWTSecurityWithCQRS_Feb20.Models;
using JWTSecurityWithCQRS_Feb20.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JWTSecurityWithCQRS_Feb20.Controllers
{

    [EnableCors("swagger")] 
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]     
    public class AdminController : ControllerBase
    {
        //Communication Using Mediator
        private readonly IMediator _mediator;
        public AdminController(IMediator mediator)
        {
            _mediator = mediator;
        }
        [HttpGet]
        [Route("getProducts")]
        //getting all the products
        public async Task<ActionResult>GetProduct()
        {
            var products = await _mediator.Send(new GetProductQuery());
            return Ok(products); 
        }
        [HttpPost]
        [Route("addProduct")]
        //adding the products
        public async Task<ActionResult> CreateProduct([FromBody]Product product)
        {
            await _mediator.Send(new AddProductCommand(product));
            return StatusCode(201); 
        }
        [HttpPut]
        [Route("updateProduct")]
        //updating the products
        public async Task<ActionResult> UpdateProduct([FromBody]Product product)
        {
            await _mediator.Send(new UpdateProductCommand(product));
            return StatusCode(201);
        }
        [HttpDelete]
        [Route("id")] 
        //Deleting a product by id
        public async Task<ActionResult>DeleteProduct(int id)
        {
            await _mediator.Send(new DeleteProductCommand(id));
            return StatusCode(200); 
        }
    }
}
