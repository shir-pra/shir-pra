﻿using JWTSecurityWithCQRS_Feb20.DataAccess;
using JWTSecurityWithCQRS_Feb20.Models;
using JWTSecurityWithCQRS_Feb20.Queries;
using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Handlers
{
    //Implementing Handlers with help of Interface and Commands.
    //GetProductQuery is Request and List<Product> is Response 
    public class GetProductHandler:IRequestHandler<GetProductQuery,List<Product>>
    {
        private readonly IProduct _product;
        public GetProductHandler(IProduct product)
        {
           _product = product;
        }

        public async Task<List<Product>> Handle(GetProductQuery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_product.GetAll()); 
        }
    }
}
