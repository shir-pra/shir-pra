﻿using JWTSecurityWithCQRS_Feb20.Commands;
using JWTSecurityWithCQRS_Feb20.DataAccess;
using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Handlers
{
    //Implementing Handlers with help of Interface and Commands.
    //DeleteProductCommand is Request and string  is Response 
    public class DeleteProductHandler:IRequestHandler<DeleteProductCommand,string>
    {
        private readonly IProduct _product;
        public DeleteProductHandler(IProduct product)
        {
            _product = product;
        }

        public async Task<string> Handle(DeleteProductCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_product.Delete(request.id));
        }
    }
}
