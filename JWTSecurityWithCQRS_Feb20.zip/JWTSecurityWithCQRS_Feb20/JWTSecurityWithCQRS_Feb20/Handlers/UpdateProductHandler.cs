﻿using JWTSecurityWithCQRS_Feb20.Commands;
using JWTSecurityWithCQRS_Feb20.DataAccess;
using JWTSecurityWithCQRS_Feb20.Models;
using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Handlers
{
    //Implementing Handlers with help of Interface and Commands.
    //UpdateProductCommand is Request and List<Product> is Response 
    public class UpdateProductHandler:IRequestHandler<UpdateProductCommand,List<Product>>
    {
        private readonly IProduct _product;
        public UpdateProductHandler(IProduct product)
        {
            _product = product;
        }

        public async Task<List<Product>> Handle(UpdateProductCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_product.Update(request.product)); 
        }
    }
}
