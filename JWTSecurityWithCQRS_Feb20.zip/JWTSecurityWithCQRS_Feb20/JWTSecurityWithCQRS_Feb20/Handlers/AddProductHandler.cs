﻿using JWTSecurityWithCQRS_Feb20.Commands;
using JWTSecurityWithCQRS_Feb20.DataAccess;
using JWTSecurityWithCQRS_Feb20.Models;
using MediatR;

namespace JWTSecurityWithCQRS_Feb20.Handlers
{
    //Implementing Handlers with help of Interface and Commands.
    //AddProductCommand is Request and List<Product> is Response 
    public class AddProductHandler:IRequestHandler<AddProductCommand,List<Product>>
    {
        private readonly IProduct _product;
        public AddProductHandler(IProduct product)
        {
            _product = product;
        }

        public async Task<List<Product>> Handle(AddProductCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_product.Create(request.product)); 
        }
    }
}
